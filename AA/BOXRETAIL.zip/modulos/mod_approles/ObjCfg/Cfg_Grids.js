function CfgGrids(id,Param){
var ret={};

ret["GR_1x4"]={
    "id": "GR_1x4",
    "CssClass": "",
    "Testing": "0",
    "Style": {},
    "Rows": {
        "0": {
            "Style": {},
            "CssClass": "",
            "Cols": {
                "0": {
                    "Style": {},
                    "CssClass": ""
                },
                "1": {
                    "Style": {
                        "0": {
                            "Prop": "Width",
                            "Value": "40vw"
                        },
                        "1": {
                            "Prop": "Height",
                            "Value": "min-content"
                        }
                    },
                    "CssClass": ""
                },
                "2": {
                    "Style": {},
                    "CssClass": ""
                },
                "3": {
                    "Style": {},
                    "CssClass": ""
                }
            }
        }
    }
};

   if(id=="" || id==undefined){return ret;}
    else{
                            if(ret[id])return ret[id];
                            else {}}
}
