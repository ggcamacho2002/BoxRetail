function CfgBiFormSel(id,Param){
var ret={};


   if(id=="" || id==undefined){return ret;}
    else{
                            if(ret[id])return ret[id];
                            else {}}
}
