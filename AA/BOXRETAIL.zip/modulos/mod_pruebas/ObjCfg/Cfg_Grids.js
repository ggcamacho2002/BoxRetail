function CfgGrids(id,Param){
var ret={};

ret["GR_1x1"]={
    "id": "GR_1x1",
    "CssClass": "",
    "Testing": 0,
    "Style": {},
    "Rows": {
        "0": {
            "Style": {},
            "CssClass": "",
            "Cols": {
                "1": {
                    "Style": {},
                    "CssClass": ""
                }
            },
        }
    }
};

///UltimoRegistroDelCfg///

   if(id=="" || id==undefined){return ret;}
    else{
                            if(ret[id])return ret[id];
                            else {}}
}
