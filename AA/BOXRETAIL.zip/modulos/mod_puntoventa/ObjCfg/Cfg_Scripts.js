function CfgScripts(id,Param){
var ret={};

ret["Scripts_SetLStoreNuevaComanda"]={
    "id": "Scripts_SetLStoreNuevaComanda",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_ProductosTrClick"]={
    "id": "Scripts_ProductosTrClick",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CargaProdPackEnter"]={
    "id": "Scripts_CargaProdPackEnter",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CargaProdUnidadEnter"]={
    "id": "Scripts_CargaProdUnidadEnter",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_ReiniciarFormCargaProd"]={
    "id": "Scripts_ReiniciarFormCargaProd",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_ProdMarcarOferta"]={
    "id": "Scripts_ProdMarcarOferta",
    "ScriptsRel": "Scripts_ProdMarcarOferta",
    "ScriptConstr": "Scripts_ProdMarcarOferta",
    "Param": {}
};
ret["Scripts_FocusBusqueda"]={
    "id": "Scripts_FocusBusqueda",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_ErrorCodigoBarra"]={
    "id": "Scripts_ErrorCodigoBarra",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CalcularSubtotal"]={
    "id": "Scripts_CalcularSubtotal",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CambiaCantidad"]={
    "id": "Scripts_CambiaCantidad",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CalcularAllItemSubtotal"]={
    "id": "Scripts_CalcularAllItemSubtotal",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_InicioPuntoVenta"]={
    "id": "Scripts_InicioPuntoVenta",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_VistaNuevaComanda"]={
    "id": "Scripts_VistaNuevaComanda",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CerrarComanda"]={
    "id": "Scripts_CerrarComanda",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_AgregarFormaCobro"]={
    "id": "Scripts_AgregarFormaCobro",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_TraerDatosCtaCte"]={
    "id": "Scripts_TraerDatosCtaCte",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_Validaciones"]={
    "id": "Scripts_Validaciones",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CambiarCliente"]={
    "id": "Scripts_CambiarCliente",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CalcularCobros"]={
    "id": "Scripts_CalcularCobros",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};

///UltimoRegistroDelCfg///

   if(id=="" || id==undefined){return ret;}
    else{
                            if(ret[id])return ret[id];
                            else {}}
}
