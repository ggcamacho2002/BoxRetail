function CfgStaticData(id,Param){
var ret={};

ret["SD_SDSDS"]={
    "id": "SD_SDSDS",
    "ListOfValue": {
        "0": {
            "Value": "",
            "Label": ""
        }
    }
};

///UltimoRegistroDelCfg///

   if(id=="" || id==undefined){return ret;}
    else{
                            if(ret[id])return ret[id];
                            else {}}
}
