function Scripts_FocusBusqueda(ObjEvt,Params){

    var bsq=document.getElementById('DSNombreProducto-0-Filtro-ST_POSListaProductos');
        bsq.focus();
        bsq.select();


}