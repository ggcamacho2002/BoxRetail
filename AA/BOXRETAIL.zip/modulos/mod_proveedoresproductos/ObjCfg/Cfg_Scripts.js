function CfgScripts(id,Param){
var ret={};

ret["Scripts_AgregarProducto"]={
    "id": "Scripts_AgregarProducto",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};

///UltimoRegistroDelCfg///

   if(id=="" || id==undefined){return ret;}
    else{
                            if(ret[id])return ret[id];
                            else {}}
}
