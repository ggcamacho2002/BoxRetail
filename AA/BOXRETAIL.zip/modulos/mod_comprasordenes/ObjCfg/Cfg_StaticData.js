function CfgStaticData(id,Param){
var ret={};

ret["SD_Dias"]={
    "id": "SD_Dias",
    "ListOfValue": {
        "0": {
            "Value": "10",
            "Label": "10"
        },
        "1": {
            "Value": "15",
            "Label": "15"
        },
        "2": {
            "Value": "20",
            "Label": "20"
        },
        "3": {
            "Value": "30",
            "Label": "30"
        },
        "4": {
            "Value": "40",
            "Label": "40"
        },
        "5": {
            "Value": "50",
            "Label": "50"
        }
    }
};

///UltimoRegistroDelCfg///

   if(id=="" || id==undefined){return ret;}
    else{
                            if(ret[id])return ret[id];
                            else {}}
}
