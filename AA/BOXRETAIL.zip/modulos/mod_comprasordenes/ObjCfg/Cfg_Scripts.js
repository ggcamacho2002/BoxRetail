function CfgScripts(id,Param){
var ret={};

ret["Scripts_CambioUnidad"]={
    "id": "Scripts_CambioUnidad",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CambioPack"]={
    "id": "Scripts_CambioPack",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CalcularTotalParcial"]={
    "id": "Scripts_CalcularTotalParcial",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CalcularSubtotal"]={
    "id": "Scripts_CalcularSubtotal",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CambioUnidadControl"]={
    "id": "Scripts_CambioUnidadControl",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CambioPackControl"]={
    "id": "Scripts_CambioPackControl",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_DiferenciasMultiples"]={
    "id": "Scripts_DiferenciasMultiples",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_ProcesarDiferencias"]={
    "id": "Scripts_ProcesarDiferencias",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_DiferenciasOneFila"]={
    "id": "Scripts_DiferenciasOneFila",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};

///UltimoRegistroDelCfg///

   if(id=="" || id==undefined){return ret;}
    else{
                            if(ret[id])return ret[id];
                            else {}}
}
