function Scripts_DiferenciasOneFila(ObjEvt,Params){

    var fila=ObjEvt.closest('tr');

    
    Scripts_ProcesarDiferencias(fila);


}