function CfgEventos(id,Param){
var ret={};

ret["EVT_Frame_TraerHtml_Respuesta"]={
    "id": "EVT_Frame_TraerHtml_Respuesta",
    "ClassEvt": "Frame_TraerHtml_Respuesta",
    "Clase": "Frame",
    "IdObj": "Frame_Respuesta",
    "IdEvt": "Frame_TraerHtml",
    "Param": {}
};

///UltimoRegistroDelCfg///

   if(id=="" || id==undefined){return ret;}
    else{
                            if(ret[id])return ret[id];
                            else {}}
}
