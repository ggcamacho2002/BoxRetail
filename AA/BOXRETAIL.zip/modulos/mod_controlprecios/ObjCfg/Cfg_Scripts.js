function CfgScripts(id,Param){
var ret={};

ret["Scripts_CalculaPackUnidad"]={
    "id": "Scripts_CalculaPackUnidad",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_SeteaPackUnidadOLd"]={
    "id": "Scripts_SeteaPackUnidadOLd",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};
ret["Scripts_CambiaPorcVenta"]={
    "id": "Scripts_CambiaPorcVenta",
    "Titulo": "",
    "Comentarios": "",
    "Inputs": {}
};

///UltimoRegistroDelCfg///

   if(id=="" || id==undefined){return ret;}
    else{
                            if(ret[id])return ret[id];
                            else {}}
}
