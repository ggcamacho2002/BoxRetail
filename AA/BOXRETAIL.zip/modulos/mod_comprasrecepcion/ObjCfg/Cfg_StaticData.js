function CfgStaticData(id,Param){
    var ret={};

   ///UltimoRegistroDelCfg///     
    if(id=="" || id==undefined){return ret;}
    else{if(ret[id])return ret[id];	else {}}

};
