function CfgParametros(id,Param){
var ret={};

ret["Globales"]={
    "id": "Globales",
    "Nombre": "Globales",
    "VistaInicio": "VT_SueldosConfigItems"
};

///UltimoRegistroDelCfg///

   if(id=="" || id==undefined){return ret;}
    else{
                            if(ret[id])return ret[id];
                            else {}}
}
